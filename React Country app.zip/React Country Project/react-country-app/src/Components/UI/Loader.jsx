import "../../App.css";

export const Loader = () => {
    
    return <div className="loader"></div>
}